CREATE VIEW Ingresos_anuales_view AS SELECT
	if2.año, 
	meses.mes, 
	(CASE WHEN mef.mes IS NOT NULL AND mef.tipo = 'EXTRA' THEN ((if2.mensualidad_bruto*dn.neto)/100)*2 
		WHEN mef.mes IS NOT NULL AND mef.tipo = 'BONUS' THEN FLOOR(((if2.bruto_anual*dn.bonus)/100))
	ELSE (if2.mensualidad_bruto*dn.neto)/100 
	END) mensualidad_neta,
	(CASE when iex.cantidad_extra IS NULL THEN  0 ELSE iex.cantidad_extra END) mensualidad_extra
FROM
	(
	WITH ContadorCTE AS (
	SELECT
			1 AS numero
UNION ALL
	SELECT
			numero + 1
	FROM
			ContadorCTE
	WHERE
			numero < 12
	)
	SELECT
			numero mes
	FROM
			ContadorCTE) meses
LEFT JOIN (
	SELECT p2.año,
		p1.numero_mes,
		p2.bruto_anual,
		p2.mensualidad_bruto 
FROM (WITH RECURSIVE Meses (numero_mes) AS (
    SELECT 1 -- El punto de inicio: el mes 1
    UNION ALL
    SELECT numero_mes + 1
    FROM Meses
    WHERE numero_mes < 12 -- La condición de parada: hasta el mes 12
)
SELECT numero_mes
FROM Meses) p1
LEFT JOIN 
(SELECT
	if2.empresa,
	if2.año,
	if2.mes_inicio,
	if2.mes_fin,
	ROUND(((if2.bruto_anual/14)*if2.mensualidades),2) bruto_anual,
	ROUND((if2.bruto_anual/14), 2) mensualidad_bruto
FROM
	ingresosFijos if2
WHERE
	activo = 1) p2
ON p1.numero_mes >= p2.mes_inicio 
and p1.numero_mes <= p2.mes_fin 
) if2
ON
	if2.numero_mes = meses.mes
LEFT JOIN (
	SELECT
		año,
		neto, 
		bonus
	FROM
		descuentosNomina) dn
ON
	dn.año = if2.año
LEFT JOIN (
	SELECT
		tipo,
		mes
	FROM
		mesesExtraFijos) mef 
ON mef.mes = meses.mes
LEFT JOIN (
	SELECT
		año, mes, SUM(cantidad) cantidad_extra
	FROM
		IngresosExtra 
	WHERE activo=1 GROUP BY año, mes ) iex 
ON iex.año = if2.año 
and iex.mes = meses.mes;

