CREATE VIEW gastos_detalle_view AS 
SELECT mes, MENSUAL,BIMENSUAL, TRIMESTRAL, CUATRIMESTRAL, SEMESTRAL, ANUAL, EXTRA, ROUND((MENSUAL+BIMENSUAL+TRIMESTRAL+CUATRIMESTRAL+SEMESTRAL+ANUAL+EXTRA),2) TOTAL  
FROM (
SELECT meses.mes, 
	mensual.cantidad MENSUAL, 
	CASE WHEN bimensual.cantidad IS NULL THEN 0 ELSE bimensual.cantidad END AS BIMENSUAL,
	CASE WHEN trimestral.cantidad IS NULL THEN 0 ELSE trimestral.cantidad END AS TRIMESTRAL,
	CASE WHEN cuatrimestral.cantidad IS NULL THEN 0 ELSE cuatrimestral.cantidad END AS CUATRIMESTRAL,
	CASE WHEN semestral.cantidad IS NULL THEN 0 ELSE semestral.cantidad END AS SEMESTRAL,
	CASE WHEN anual.cantidad IS NULL THEN 0 ELSE anual.cantidad END AS ANUAL,
	CASE WHEN extras.cantidad IS NULL THEN 0 ELSE extras.cantidad END AS EXTRA
FROM (
	WITH ContadorCTE AS (
	SELECT
			1 AS numero
	UNION ALL
	SELECT
			numero + 1
	FROM
			ContadorCTE
	WHERE
			numero < 12
	)
	SELECT
			numero mes
	FROM
			ContadorCTE) meses 
	LEFT JOIN (SELECT sum(cantidad) cantidad FROM gastosPeriodicos WHERE periodicidad ='M' and active=1) mensual 
	ON 1=1
	LEFT JOIN (SELECT mes, sum(cantidad) cantidad  FROM gastosPeriodicos WHERE periodicidad ='B' and active = 1 GROUP BY mes) bimensual
	ON bimensual.mes=meses.mes
	LEFT JOIN (SELECT mes, sum(cantidad) cantidad  FROM gastosPeriodicos WHERE periodicidad ='T' and active = 1 GROUP BY mes) trimestral
	ON trimestral.mes=meses.mes
	LEFT JOIN (SELECT mes, sum(cantidad) cantidad  FROM gastosPeriodicos WHERE periodicidad ='C' and active = 1 GROUP BY mes) cuatrimestral
	ON cuatrimestral.mes=meses.mes
	LEFT JOIN (SELECT mes, sum(cantidad) cantidad  FROM gastosPeriodicos WHERE periodicidad ='S' and active = 1 GROUP BY mes) semestral
	ON semestral.mes=meses.mes
	LEFT JOIN (SELECT mes, sum(cantidad) cantidad  FROM gastosPeriodicos WHERE periodicidad ='A' and active = 1 GROUP BY mes) anual
	ON anual.mes=meses.mes 
	LEFT JOIN (SELECT mes, SUM(cantidad) cantidad FROM gastosTemporales gt WHERE año = strftime('%Y', 'now')*1 group by mes) extras
	ON extras.mes=meses.mes);

