CREATE VIEW gastos_fijos_view AS SELECT MES, MENSUAL+BIMENSUAL+SEMESTRAL+ANUAL AS gastos_fijos 
FROM (SELECT meses.mes, 
	mensual.cantidad MENSUAL, 
	CASE WHEN bimensual.cantidad IS NULL THEN 0 ELSE bimensual.cantidad END AS BIMENSUAL,
	CASE WHEN semestral.cantidad IS NULL THEN 0 ELSE semestral.cantidad END AS SEMESTRAL,
	CASE WHEN anual.cantidad IS NULL THEN 0 ELSE anual.cantidad END AS ANUAL
FROM (
	WITH ContadorCTE AS (
	SELECT
			1 AS numero
	UNION ALL
	SELECT
			numero + 1
	FROM
			ContadorCTE
	WHERE
			numero < 12
	)
	SELECT
			numero mes
	FROM
			ContadorCTE) meses 
	LEFT JOIN (SELECT sum(cantidad) cantidad FROM gastosPeriodicos WHERE periodicidad ='M' and active=1) mensual 
	ON 1=1
	LEFT JOIN (SELECT mes, sum(cantidad) cantidad  FROM gastosPeriodicos WHERE periodicidad ='B' and active = 1 GROUP BY mes) bimensual
	ON bimensual.mes=meses.mes
	LEFT JOIN (SELECT mes, sum(cantidad) cantidad  FROM gastosPeriodicos WHERE periodicidad ='S' and active = 1 GROUP BY mes) semestral
	ON semestral.mes=meses.mes
	LEFT JOIN (SELECT mes, sum(cantidad) cantidad  FROM gastosPeriodicos WHERE periodicidad ='A' and active = 1 GROUP BY mes) anual
	ON anual.mes=meses.mes);

