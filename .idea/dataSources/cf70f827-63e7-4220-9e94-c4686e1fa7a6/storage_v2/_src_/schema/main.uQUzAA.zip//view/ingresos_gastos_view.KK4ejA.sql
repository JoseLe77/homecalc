CREATE VIEW ingresos_gastos_view AS SELECT ingresos.año, 
ingresos.mes,
ingresos.mensualidad_neta,
ingresos.mensualidad_extra,
CASE WHEN g_fijos.gastos_fijos IS NULL THEN 0 ELSE g_fijos.gastos_fijos END gastos_fijos, 
CASE WHEN g_temp.gastos_temporales IS NULL THEN 0 ELSE g_temp.gastos_temporales END gastos_temporales,
(CASE WHEN g_fijos.gastos_fijos IS NULL THEN 0 ELSE g_fijos.gastos_fijos END)+(CASE WHEN g_temp.gastos_temporales IS NULL THEN 0 ELSE g_temp.gastos_temporales END) total_gastos
FROM 
(SELECT * FROM Ingresos_anuales_view) ingresos
LEFT JOIN 
(SELECT * FROM gastos_fijos_view) g_fijos
ON ingresos.mes=g_fijos.mes
LEFT JOIN 
(SELECT año, mes, sum(cantidad) gastos_temporales FROM gastosTemporales GROUP BY año, mes) g_temp
ON ingresos.año=g_temp.año
AND ingresos.mes=g_temp.mes;

